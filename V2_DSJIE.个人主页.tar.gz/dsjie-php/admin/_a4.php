<?php
/** 访问日志视图（kind=visits）：统计卡 + 按 IP 汇总表 + 最近明细；数据源 data/visits.php */
require_once __DIR__ . '/../lib_visits.php';
function view_visits(): void {
    $rows  = visit_read();   // 新 → 旧
    $total = count($rows);
    $today = date('Y-m-d');
    $ips = []; $todayN = 0; $botN = 0;
    foreach ($rows as $r) {
        $ips[(string)($r['ip'] ?? '-')] = true;
        if (strncmp((string)($r['t'] ?? ''), $today, 10) === 0) $todayN++;
        if (!empty($r['bot'])) $botN++;
    }
    $uniq = count($ips);
    $last = $rows ? (string)($rows[0]['t'] ?? '') : '—';

    // 按 IP 汇总：records 为新→旧，首次=循环到的最后一条，最近/设备=首见那条
    $g = [];
    foreach ($rows as $r) {
        $ip = (string)($r['ip'] ?? '-');
        if (!isset($g[$ip])) {
            $g[$ip] = ['ip'=>$ip, 'n'=>0, 'first'=>'', 'last'=>'',
                       'dev'=>(string)($r['dev'] ?? '-'), 'br'=>(string)($r['br'] ?? '-'),
                       'os'=>(string)($r['os'] ?? '-'), 'bot'=>(int)($r['bot'] ?? 0),
                       'p'=>(string)($r['p'] ?? '/')];
        }
        $g[$ip]['n']++;
        $g[$ip]['first'] = (string)($r['t'] ?? '');
        if ($g[$ip]['last'] === '') $g[$ip]['last'] = (string)($r['t'] ?? '');
    }
    usort($g, function ($a, $b) { return strcmp($b['last'], $a['last']); });

    echo '<style>
.vstats{display:grid;grid-template-columns:repeat(auto-fit,minmax(128px,1fr));gap:12px;margin-bottom:14px;}
.vst{background:var(--tint);border:1px solid var(--border);border-radius:14px;padding:13px 15px;}
.vst span{font-size:12px;color:var(--t3);letter-spacing:1px;}
.vst b{display:block;font-size:22px;margin-top:4px;line-height:1.15;}
.vst b.sm{font-size:15px;}
.vbar{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin:2px 0 14px;font-size:13px;}
.vbar label{display:flex;gap:6px;align-items:center;cursor:pointer;color:var(--t2);}
.vbtn{border:1px solid var(--border);background:var(--card);color:inherit;border-radius:10px;padding:7px 14px;font-size:13px;cursor:pointer;}
.vbtn:hover{background:var(--tint);}
.vtag{display:inline-block;font-size:11px;border:1px solid var(--border);border-radius:999px;padding:1px 8px;color:var(--t2);margin-left:4px;}
tr.vbot td{opacity:.62;}
.vhint{color:var(--t3);font-size:12px;}
</style>';

    echo '<div class="panel"><div class="ptop"><h2>访问日志 <span class="num">共 ' . $total . ' 条记录</span></h2>'
       . '<button class="vbtn" onclick="location.reload()">刷新</button></div>';

    if ($total === 0) {
        echo '<p class="empty">还没有访问记录。前台被打开后会自动记录 IP、时间、设备、浏览器和来路。</p></div>';
        return;
    }

    echo '<div class="vstats">'
       . '<div class="vst"><span>总访问</span><b>' . $total . '</b></div>'
       . '<div class="vst"><span>独立访客 IP</span><b>' . $uniq . '</b></div>'
       . '<div class="vst"><span>今日访问</span><b>' . $todayN . '</b></div>'
       . '<div class="vst"><span>爬虫记录</span><b>' . $botN . '</b></div>'
       . '<div class="vst"><span>最近访问</span><b class="sm">' . e($last) . '</b></div>'
       . '</div>';

    echo '<div class="vbar">'
       . '<label><input type="checkbox" id="vshowbot" checked> 显示爬虫</label>'
       . '<button class="vbtn" id="vcsv">导出 CSV</button>'
       . '<span class="vhint">日志存于 data/visits.php，超过 800KB 自动归档</span></div>';

    echo '<table class="tbl" id="vtable"><tr><th>访客 IP</th><th>次数</th><th>最近时间</th><th>首次时间</th><th>设备</th><th>浏览器</th><th>系统</th><th>最近页面</th></tr>';
    foreach ($g as $x) {
        $isb = ((int)$x['bot'] === 1);
        echo '<tr' . ($isb ? ' class="vbot" data-bot="1"' : ' data-bot="0"') . '>'
           . '<td data-label="访客 IP">' . e($x['ip']) . ($isb ? ' <span class="vtag">爬虫</span>' : '') . '</td>'
           . '<td data-label="次数">' . (int)$x['n'] . '</td>'
           . '<td data-label="最近时间">' . e($x['last']) . '</td>'
           . '<td data-label="首次时间">' . e($x['first']) . '</td>'
           . '<td data-label="设备">' . e($x['dev']) . '</td>'
           . '<td data-label="浏览器">' . e($x['br']) . '</td>'
           . '<td data-label="系统">' . e($x['os']) . '</td>'
           . '<td data-label="最近页面">' . e($x['p']) . '</td></tr>';
    }
    echo '</table>';

    echo '<h3 class="sub" style="margin-top:26px">最近明细 · 最新 20 条</h3>'
       . '<table class="tbl"><tr><th>时间</th><th>IP</th><th>设备</th><th>浏览器</th><th>系统</th><th>页面</th><th>来路</th></tr>';
    foreach (array_slice($rows, 0, 20) as $r) {
        $isb = !empty($r['bot']);
        $ref = trim((string)($r['r'] ?? ''));
        echo '<tr' . ($isb ? ' class="vbot" data-bot="1"' : ' data-bot="0"') . '>'
           . '<td data-label="时间">' . e((string)($r['t'] ?? '')) . '</td>'
           . '<td data-label="IP">' . e((string)($r['ip'] ?? '')) . '</td>'
           . '<td data-label="设备">' . e((string)($r['dev'] ?? '')) . '</td>'
           . '<td data-label="浏览器">' . e((string)($r['br'] ?? '')) . '</td>'
           . '<td data-label="系统">' . e((string)($r['os'] ?? '')) . '</td>'
           . '<td data-label="页面">' . e((string)($r['p'] ?? '')) . '</td>'
           . '<td data-label="来路">' . e($ref !== '' ? $ref : '直接访问') . '</td></tr>';
    }
    echo '</table>';

    echo <<<'HTML'
<script>
(function(){
  var cb=document.getElementById('vshowbot');
  function f(){
    var on=cb.checked, list=document.querySelectorAll('[data-bot="1"]');
    for(var i=0;i<list.length;i++){list[i].style.display=on?'':'none';}
  }
  cb.addEventListener('change',f); f();
  document.getElementById('vcsv').addEventListener('click',function(){
    var t=document.getElementById('vtable'), out=['访客IP,次数,最近时间,首次时间,设备,浏览器,系统,最近页面'];
    for(var i=1;i<t.rows.length;i++){
      var r=t.rows[i];
      if(r.getAttribute('data-bot')==='1'&&!cb.checked) continue;
      var c=[];
      for(var j=0;j<r.cells.length;j++){
        var txt=r.cells[j].innerText.replace('爬虫','').trim();
        c.push('"'+txt.replace(/"/g,'""')+'"');
      }
      out.push(c.join(','));
    }
    var blob=new Blob(['\ufeff'+out.join('\r\n')],{type:'text/csv;charset=utf-8'});
    var a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download='visits_'+new Date().toISOString().slice(0,10)+'.csv';
    a.click();
  });
})();
</script>
HTML;
    echo '</div>';
}
