<?php
/** 留言回复 / 删除 与 账号维护 类 POST 动作（由 _a1b.php 分发调用） */
function admin_misc_post(string $do, array &$data, string $m): string {
    if ($do === 'delete_msg') {
        $id = (string)($_POST['id'] ?? '');
        $data['messages'] = array_values(array_filter($data['messages'], function ($x) use ($id) { return ($x['id'] ?? '') !== $id; }));
        $m = '留言已删除';
    } elseif ($do === 'save_reply') {
        $mid = (string)($_POST['msg_id'] ?? '');
        $txt = clean_text((string)($_POST['reply'] ?? ''), 200);
        $mq = trim((string)($data['site']['master_qq'] ?? ''));
        $qv = $mq !== '' ? $mq : ('站长 ' . admin_creds()['user']);
        foreach ($data['messages'] as $k => $mm) {
            if (($mm['id'] ?? '') === $mid && $txt !== '') {
                $data['messages'][$k]['replies'][] = [
                    'id' => nid(), 'qq' => $qv, 'role' => 'master',
                    'email' => '', 'text' => $txt, 'time' => now_str(),
                ];
            }
        }
        $m = '回复已发布';
    } elseif ($do === 'delete_reply') {
        $mid = (string)($_POST['msg_id'] ?? ''); $rid = (string)($_POST['rid'] ?? '');
        foreach ($data['messages'] as $k => $mm) {
            if (($mm['id'] ?? '') === $mid) {
                $data['messages'][$k]['replies'] = array_values(array_filter($mm['replies'] ?? [], function ($x) use ($rid) { return ($x['id'] ?? '') !== $rid; }));
            }
        }
        $m = '回复已删除';
    } elseif ($do === 'save_account') {
        $u = clean_text((string)($_POST['user'] ?? ''), 30);
        $p1 = (string)($_POST['pass1'] ?? ''); $p2 = (string)($_POST['pass2'] ?? '');
        if ($u === '') $m = '用户名不能为空';
        elseif ($p1 !== '' && $p1 !== $p2) $m = '两次密码不一致';
        else {
            $j = ['user' => $u];
            if ($p1 !== '') $j['pass_hash'] = password_hash($p1, PASSWORD_DEFAULT);
            else { $c = admin_creds(); if ($c['hash']) $j['pass_hash'] = $c['hash']; else $j['pass'] = $c['plain']; }
            @file_put_contents(ADMIN_FILE, json_encode($j, JSON_PRETTY_PRINT), LOCK_EX);
            $m = '账号已更新';
        }
    }
    return $m;
}
