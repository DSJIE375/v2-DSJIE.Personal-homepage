<?php
/* ---------- 分发 + 布局（由 _a3.php 加载） ---------- */
if (!$logged) { view_login($err); exit; }
$data = load_data();
$kind = $TYPES[$pnow]['kind'];

$item = null;
if ($kind === 'list' && ($act === 'edit' || $act === 'new')) {
    if ($act === 'edit') {
        $want = (string)($_GET['id'] ?? '');
        foreach ($data[$pnow] as $it) if (($it['id'] ?? '') === $want) { $item = $it; break; }
        if ($item === null) { header('Location: index.php?p=' . $pnow . '&msg=条目不存在'); exit; }
    } else {
        $item = ['id' => ''];
    }
}

header('Content-Type: text/html; charset=utf-8');
echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
   . '<title>后台管理 · DSJIE</title><script>(function(){var m=null;try{m=localStorage.getItem("dsjie_theme")}catch(e){}var d=m==="dark"||(m!=="light"&&window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches);document.documentElement.setAttribute("data-theme",d?"dark":"light");})();</script><link rel="stylesheet" href="style.css">' . admin_palette() . $site_bg_js . '</head><body class="apage">'
   . '<header class="ahead"><span class="alogo">DSJIE 后台</span><span class="aact">'
   . '<a href="../index.php" target="_blank">查看前台 ↗</a>'
   . '<form method="post" class="logoutf"><button name="do" value="logout" class="btn ghost">退出登录</button></form>'
   . '</span></header><div class="awrap"><nav class="anav">';
foreach ($TYPES as $k => $tdef) {
    $badge = ($k === 'messages' && count($data['messages'])) ? '<b class="cnt">' . count($data['messages']) . '</b>' : '';
    echo '<a class="navi' . ($k === $pnow ? ' on' : '') . '" href="index.php?p=' . $k . '">' . e($tdef['label']) . $badge . '</a>';
}
echo '</nav><main class="amain">';
if ($msg !== '') echo '<div class="flash">' . e($msg) . '</div>';

if ($kind === 'list') {
    if ($item !== null) view_form($pnow, $TYPES[$pnow], $item);
    else view_list($pnow, $TYPES[$pnow], $data[$pnow]);
} elseif ($kind === 'settings') view_settings($pnow, $TYPES[$pnow], $data);
elseif ($kind === 'visits') view_visits();
elseif ($kind === 'messages') view_messages($data['messages']);
elseif ($kind === 'account') view_account(admin_creds());

echo '</main></div><footer class="afoot">DSJIE 个人主页 · 后台 v1.0</footer></body></html>';