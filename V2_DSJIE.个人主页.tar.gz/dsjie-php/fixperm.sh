#!/bin/sh
# DSJIE 站点权限一键修复
# 把本文件放站点根目录（与 index.php 同级），解压新包后若提示没权限，执行一次：  sh fixperm.sh
cd "$(dirname "$0")" || exit 1
find . -type d -exec chmod 755 {} +
find . -type f -exec chmod 644 {} +
chmod -R 777 data uploads files 2>/dev/null
chmod 755 data/content.json 2>/dev/null
echo "OK：目录 755 / 文件 644 / data、uploads、files 可写 777 / content.json 755"
