/* 开场两栏 ↔ 左中右三栏
   - 打开：导航贴左 + 头像板铺满右侧（解析几何：不读过渡中的矩形，宽度位移同曲线）
   - 下滚 / 点击导航：展开三栏；三栏回到第一板块顶部上滚：还原开场
   - 开场态下向上滚不做任何事 */
(function () {
  var win = document.querySelector('.window');
  if (!win) return;
  var wb = win.querySelector('.winbody');
  var side = win.querySelector('.side');
  var nav = win.querySelector('.navcol');
  var main = win.querySelector('.content');
  if (!wb || !side || !nav || !main) return;
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var active = false, animating = false, lastToggle = 0;

  function isDesk() {
    return window.matchMedia && window.matchMedia('(min-width:768px)').matches;
  }

  /* 解析几何：侧栏宽 = 窗体宽 - 导航列 - 48，左边距贴导航右侧 24px（右自然余 24px）；
     navDx / sideDx 只依赖窗体矩形与已知宽度，不受过渡动画中的布局影响 */
  function measure() {
    var w = wb.getBoundingClientRect();
    var navW = nav.offsetWidth;
    var introW = Math.max(400, w.width - navW - 48);
    side.style.width = introW + 'px';
    if (!isDesk()) {
      nav.style.transform = '';
      side.style.transform = '';
      return;
    }
    nav.style.transform = 'translateX(' + (-introW) + 'px)';
    side.style.transform = 'translateX(' + (navW + 24) + 'px)';
  }

  function toggle(on) {
    var now = Date.now();
    if (animating || now - lastToggle < 820) return false;
    if (on === active) return false;
    lastToggle = now;
    active = on;
    if (!reduce) { win.classList.add('wintro-anim'); animating = true; }
    if (on) {
      win.classList.add('intro');
      measure();
    } else {
      win.classList.remove('intro');
      nav.style.transform = '';
      side.style.transform = '';
      side.style.width = '';
    }
    if (!reduce) {
      setTimeout(function () { win.classList.remove('wintro-anim'); animating = false; }, 850);
    } else {
      animating = false;
    }
    return true;
  }

  /* 供导航点击调用：处于开场态时收起（非开场态为无操作） */
  window.dsjieIntroExit = function () { toggle(false); };

  function onWheel(e) {
    var dy = e.deltaY;
    if (!dy) return;
    if (active) {
      /* 开场态：只有向下滚才展开，向上滚什么都不做 */
      if (dy > 0) { e.preventDefault(); toggle(false); }
      return;
    }
    if (dy < 0 && isDesk()) {
      var sc = win.querySelector('.scroll');
      var atTop = sc ? sc.scrollTop <= 1 : false;
      var atFirst = (typeof window.cur === 'undefined') ? true : window.cur === 0;
      if (atTop && atFirst && toggle(true)) e.preventDefault();
    }
  }

  /* 首次加载仅桌面进入开场态（loader 遮住初始帧） */
  if (isDesk()) {
    active = true;
    win.classList.add('intro');
    measure();
  }

  window.addEventListener('wheel', onWheel, { passive: false });
  window.addEventListener('resize', function () { if (active && !animating) measure(); });
})();
