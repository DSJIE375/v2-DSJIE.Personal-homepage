<?php
/** 板块渲染器（下）：下载 / 留言板 / 动态 / 友链 + 板块总装 */

function fold_apply(string $h, string $tag, int $limit): string {
    $total = substr_count($h, $tag);
    if ($total <= $limit) return $h;

    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $dom->loadHTML('<?xml encoding="UTF-8">' . $h, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);

    $nodes = $dom->getElementsByTagName('*');
    $idx = 0;
    foreach ($nodes as $node) {
        if (!$node->hasAttribute('class')) continue;
        $classes = preg_split('/\s+/', trim($node->getAttribute('class')));
        if (!in_array($tag, $classes, true)) continue;
        if ($idx >= $limit) {
            $classes[] = 'folded';
            $node->setAttribute('class', trim(implode(' ', $classes)));
        }
        $idx++;
    }

    $body = $dom->getElementsByTagName('body')->item(0);
    if (!$body) return $dom->saveHTML();
    $inner = '';
    foreach ($body->childNodes as $child) {
        $inner .= $dom->saveHTML($child);
    }
    return $inner;
}

/** 下载（文件大小对 files/ 下真实文件自动读取 filesize，文件不存在时回退手填 note） */
function render_downloads(array $d): string {
    $h = "<section class='sect'>" . sect_head('下载', 'FILES');
    foreach ($d['downloads'] as $f) {
        $file = trim((string)($f['file'] ?? ''));
        $note = trim((string)($f['note'] ?? ''));
        $size = '';
        if ($file !== '') {
            $full = __DIR__ . '/' . $file;
            if (is_file($full)) {
                $bytes = (int)@filesize($full);
                $size = $bytes >= 1048576
                    ? round($bytes / 1048576, 1) . ' MB'
                    : ($bytes >= 1024 ? (int)ceil($bytes / 1024) . ' KB' : $bytes . ' B');
            }
        }
        if ($size !== '') {
            $desc = $note;
            if ($note !== '' && mb_strpos($note, '·') !== false) {
                $desc = trim(mb_substr($note, mb_strpos($note, '·') + 1));
            }
            $dsize = $size . ($desc !== '' ? ' · ' . $desc : '');
        } else {
            $dsize = $note;
        }
        $h .= "<div class='drow'><div class='dinfo'>"
            . "<span class='dname'>" . e($f['title'] ?? '') . '</span>'
            . "<span class='dsize'>" . e($dsize) . '</span></div>'
            . "<button class='dbtn' type='button' data-url='" . e($file) . "' data-name='"
            . e($f['title'] ?? '') . "'>下载</button></div>";
    }
    $h = fold_apply($h, 'drow', 5);
    return $h . '</section>';
}

/** 留言板（表单 + 容器，消息由前端 gPaint 用 window.GBOOK 渲染） */
function render_guestbook(array $d): string {
    return "<section class='sect'>" . sect_head('留言板', 'GUESTBOOK') . contact_card() .
        "<form class='gform' autocomplete='off'>" .
        "<input class='gif gqq' type='text' inputmode='numeric' maxlength='12' placeholder='QQ 号（5-12 位数字）'>" .
        "<input class='gif gemail' type='text' placeholder='邮箱（必填）'>" .
        "<textarea class='gif txt gtext' rows='3' maxlength='200' placeholder='留言内容（必填，200 字内）'></textarea>" .
        "<input class='gif gpass' hidden type='password' maxlength='30' placeholder='站长/开发者身份校验码'>" .
        "<button class='gsubmit' type='submit'>发表留言</button>" .
        "</form><div class='gmsgs'></div></section>";
}

/** 版权模块（将原页脚版权迁移到单独板块展示） */
function render_copyright(array $d): string {
    $footer = trim((string)($d['site']['footer'] ?? ''));
    if ($footer === '') {
        return "<section class='sect'>" . sect_head('版权', 'COPYRIGHT') . "<div class='copybox'><p>暂无版权信息</p></div></section>";
    }
    $items = preg_split('/\\R/u', $footer, -1, PREG_SPLIT_NO_EMPTY) ?: [];
    $items = array_values(array_filter(array_map('trim', $items), static function ($item) {
        return $item !== '';
    }));
    $items = array_reverse($items);
    $boxes = '';
    foreach ($items as $item) {
        $item = strip_tags($item, '<strong><em><br><a><code>');
        $boxes .= "<div class='copybox'><p>" . $item . '</p></div>';
    }
    return "<section class='sect'>" . sect_head('版权', 'COPYRIGHT') . $boxes . '</section>';
}

/** 动态 */
function render_updates(array $d): string {
    $h = "<section class='sect'>" . sect_head('动态', 'UPDATES') . "<div class='timeline'>";
    foreach ($d['updates'] as $u) {
        $h .= "<div class='tlitem'><span class='tldate'>" . e($u['date'] ?? '') . '</span>'
            . '<div class="tlbody"><h4>' . e($u['title'] ?? '') . '</h4>'
            . '<p>' . e($u['text'] ?? '') . '</p></div></div>';
    }
    $h = fold_apply($h, 'tlitem', 5);
    return $h . '</div></section>';
}

/** 友情链接（头像字段填图片链接 → 显示图片；留单字 → 显示文字；空 → 取首字） */
function render_friends(array $d): string {
    $h = "<section class='sect'>" . sect_head('友情链接', 'FRIENDS') . "<div class='friends'>";
    foreach ($d['friends'] as $fr) {
        $name = (string)($fr['name'] ?? '');
        $av = trim((string)($fr['avatar'] ?? ''));
        $url = trim((string)($fr['url'] ?? ''));
        if ($url === '') $url = '#';
        if ($av === '') {
            $avh = e(mb_substr($name, 0, 1, 'UTF-8'));
        } elseif (preg_match('#^(https?:)?//|^/|^\./|\.(png|jpe?g|gif|webp|svg)$#i', $av)) {
            $avh = "<img src='" . e($av) . "' alt='" . e($name) . "' loading='lazy'>";
        } else {
            $avh = e($av);
        }
        $h .= "<a class='fcard' href='" . e($url) . "' target='_blank' rel='noopener'>"
            . "<span class='favatar'>" . $avh . '</span>'
            . '<div class="finfo"><h4>' . e($name) . '</h4>'
            . '<p>' . e($fr['desc'] ?? '') . '</p></div></a>';
    }
    $h = fold_apply($h, 'fcard', 6);
    return $h . '</div></section>';
}

/** 全部板块（顺序固定，与导航 data-i 一一对应） */
function build_sections(array $d): array {
    return [
        ['id' => 'about',     'html' => render_about($d)],
        ['id' => 'works',     'html' => render_works($d)],
        ['id' => 'essays',    'html' => render_essays($d)],
        ['id' => 'gallery',   'html' => render_gallery($d)],
        ['id' => 'updates',   'html' => render_updates($d)],
        ['id' => 'friends',   'html' => render_friends($d)],
        ['id' => 'downloads', 'html' => render_downloads($d)],
        ['id' => 'guestbook', 'html' => render_guestbook($d)],
        ['id' => 'copyright', 'html' => render_copyright($d)],
    ];
}