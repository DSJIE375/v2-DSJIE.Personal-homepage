<?php
/** DSJIE 个人主页 - 后台管理（模型 + 认证 + GET 状态；POST 路由见 _a1b.php） */
session_start();
require_once __DIR__ . '/../lib.php';
require_once __DIR__ . '/../theme.php';
require_once __DIR__ . '/../setup.php';

/* 未部署 → 自动跳转安装向导（部署过的站点不会触碰 install.php） */
if (!is_file(ADMIN_FILE) || !is_file(IDENTITY_FILE)) {
  header('Location: ../install.php');
  exit;
}

/* ---------- 内容模型：字段即后台表单项 ---------- */
$TYPES = [
  'site' => ['label' => '站点设置', 'kind' => 'settings', 'fields' => [
    ['key'=>'grp_basics','label'=>'基本信息','type'=>'heading'],
    ['key'=>'name','label'=>'站点名（Logo/页头）','type'=>'text'],
    ['key'=>'logo','label'=>'Logo 图片链接（空=显示站点名首字）','type'=>'text'],
    ['key'=>'avatar','label'=>'头像文字（未上传头像图时显示）','type'=>'text'],
    ['key'=>'avatar_img','label'=>'头像图片链接（http 图片地址，空=显示头像文字）','type'=>'text'],
    ['key'=>'slogan1','label'=>'口号第一句（打字机先显示）','type'=>'text'],
    ['key'=>'slogan2','label'=>'口号第二句（第一句退回后显示，循环）','type'=>'text'],
    ['key'=>'welcome','label'=>'欢迎语（口号下方，如：欢迎进入我的个人主页）','type'=>'text'],
    ['key'=>'footer','label'=>'页脚版权（每行一条，支持 strong/em/br/a/code 标签）','type'=>'html'],
    ['key'=>'grp_contact','label'=>'联系与按钮','type'=>'heading'],
    ['key'=>'contact_text','label'=>'联系按钮文字','type'=>'text'],
    ['key'=>'contact_url','label'=>'联系方式链接（mailto: 或 https:）','type'=>'text'],
    ['key'=>'ct_phone','label'=>'联系手机（多个用、分隔；前台自动打码如 138****5678；留空隐藏）','type'=>'text'],
    ['key'=>'ct_email','label'=>'联系邮箱（多个用、分隔；前台展示；留空隐藏）','type'=>'text'],
    ['key'=>'ct_addr','label'=>'地址信息（前台展示，建议写到市级；留空隐藏）','type'=>'text'],
    ['key'=>'blog_text','label'=>'博客按钮文字（留空则不显示）','type'=>'text'],
    ['key'=>'blog_url','label'=>'博客链接（https://…）','type'=>'text'],
    ['key'=>'grp_mail','label'=>'邮件通知','type'=>'heading'],
    ['key'=>'smtp_host','label'=>'SMTP 服务器地址','type'=>'text'],
    ['key'=>'smtp_port','label'=>'SMTP 端口（常用 SSL 465 / STARTTLS 587）','type'=>'text'],
    ['key'=>'smtp_secure','label'=>'SMTP 加密方式','type'=>'select','options'=>[['value'=>'tls','label'=>'STARTTLS'],['value'=>'ssl','label'=>'SSL/TLS'],['value'=>'none','label'=>'不加密']]],
    ['key'=>'smtp_username','label'=>'SMTP 登录账号','type'=>'text'],
    ['key'=>'smtp_password','label'=>'SMTP 密码/授权码（留空保持原值）','type'=>'secret'],
    ['key'=>'mail_notify_to','label'=>'新留言通知收件邮箱（留空关闭新留言通知）','type'=>'text'],
    ['key'=>'mail_from','label'=>'通知发件邮箱（通常与 SMTP 账号相同）','type'=>'text'],
    ['key'=>'grp_master','label'=>'留言身份（站长标签）','type'=>'heading'],
    ['key'=>'master_qq','label'=>'站长 QQ 号（该 QQ+口令提交的留言/回复显示站长标签，5-12 位数字）','type'=>'text'],
    ['key'=>'master_pwd','label'=>'站长身份口令（QQ 与口令同时匹配才生效，留空不启用）','type'=>'text'],
    ['key'=>'grp_theme','label'=>'外观主题','type'=>'heading'],
    ['key'=>'theme_color','label'=>'整站配色主色（点色盘选色；填写后背景/文字/边框/按钮整站黑白灰体系全部跟随变色，明暗两主题联动；留空或点恢复默认=默认黑白灰）','type'=>'color'],
    ['key'=>'bg_image','label'=>'全站背景图片链接（贴图片 URL 或 /uploads/xx.jpg 路径，铺满整页自动加明暗遮罩保证可读；留空 = 不显示背景图）','type'=>'text'],
    ['key'=>'grp_beian','label'=>'备案信息','type'=>'heading'],
    ['key'=>'icp_text','label'=>'ICP 备案号（留空则不显示）','type'=>'text'],
    ['key'=>'icp_url','label'=>'ICP 备案链接（默认工信部官网）','type'=>'text'],
    ['key'=>'gp_text','label'=>'公安备案号（留空则不显示）','type'=>'text'],
    ['key'=>'gp_url','label'=>'公安备案链接（默认公安部官网）','type'=>'text'],
    ['key'=>'grp_seo','label'=>'SEO 设置','type'=>'heading'],
    ['key'=>'seo_title','label'=>'网站标题','type'=>'text'],
    ['key'=>'seo_desc','label'=>'SEO 描述','type'=>'textarea'],
    ['key'=>'seo_keywords','label'=>'SEO 关键词','type'=>'text'],
  ]],
  'about' => ['label' => '关于我', 'kind' => 'settings', 'fields' => [
    ['key'=>'intro','label'=>'简介（支持 <strong> 加粗）','type'=>'html'],
    ['key'=>'skills','label'=>'技能标签（逗号分隔）','type'=>'text'],
    ['key'=>'radar','label'=>'雷达图（每行一条：名称:0-100）','type'=>'textarea'],
  ]],
  'works' => ['label' => '作品', 'kind' => 'list', 'fields' => [
    ['key'=>'title','label'=>'标题','type'=>'text'],
    ['key'=>'desc','label'=>'简介','type'=>'textarea'],
    ['key'=>'tech','label'=>'技术栈','type'=>'text'],
    ['key'=>'pic','label'=>'展示图（图片链接，空=标题首字）','type'=>'text'],
    ['key'=>'link','label'=>'链接（空=不跳转）','type'=>'text'],
  ]],
  'essays' => ['label' => '随笔', 'kind' => 'list', 'fields' => [
    ['key'=>'title','label'=>'标题','type'=>'text'],
    ['key'=>'date','label'=>'日期（2026.10.16）','type'=>'text'],
    ['key'=>'excerpt','label'=>'摘要','type'=>'textarea'],
    ['key'=>'content','label'=>'正文','type'=>'big'],
  ]],
  'gallery' => ['label' => '图库', 'kind' => 'list', 'fields' => [
    ['key'=>'caption','label'=>'图片说明','type'=>'text'],
    ['key'=>'date','label'=>'日期（2026.10）','type'=>'text'],
    ['key'=>'img','label'=>'图片','type'=>'upload','dir'=>'uploads','accept'=>'image/*'],
  ]],
  'downloads' => ['label' => '下载', 'kind' => 'list', 'fields' => [
    ['key'=>'title','label'=>'文件名','type'=>'text'],
    ['key'=>'note','label'=>'说明（128 KB · 简历）','type'=>'text'],
    ['key'=>'file','label'=>'文件','type'=>'upload','dir'=>'files','accept'=>'*/*'],
  ]],
  'updates' => ['label' => '动态', 'kind' => 'list', 'fields' => [
    ['key'=>'date','label'=>'日期','type'=>'text'],
    ['key'=>'title','label'=>'标题','type'=>'text'],
    ['key'=>'text','label'=>'内容','type'=>'textarea'],
  ]],
  'friends' => ['label' => '友链', 'kind' => 'list', 'fields' => [
    ['key'=>'name','label'=>'名称','type'=>'text'],
    ['key'=>'url','label'=>'网址','type'=>'text'],
    ['key'=>'desc','label'=>'简介','type'=>'text'],
    ['key'=>'avatar','label'=>'头像（填图片链接显示图片，留单字显示文字，空=取首字）','type'=>'text'],
  ]],
  'visits' => ['label' => '访问日志', 'kind' => 'visits', 'fields' => []],
  'analytics' => ['label' => '点击统计', 'kind' => 'analytics', 'fields' => []],
  'messages' => ['label' => '留言板', 'kind' => 'messages', 'fields' => []],
  'account' => ['label' => '账号', 'kind' => 'account', 'fields' => []],
];

/* ---------- 字段读写 ---------- */
function fld_post(array $f): string {
    $v = (string)($_POST[$f['key']] ?? '');
    if ($f['type'] === 'html')     return trim(strip_tags($v, '<strong><em><br><a><code>'));
    if ($f['type'] === 'big')      return mb_substr(trim($v), 0, 20000, 'UTF-8');
    if ($f['type'] === 'textarea') return mb_substr(trim(strip_tags($v)), 0, 2000, 'UTF-8');
    return clean_text($v, 300);
}

require __DIR__ . '/_a1b.php';

/* ---------- GET 状态 ---------- */
$logged = !empty($_SESSION['admin']);
$pnow = preg_replace('/[^a-z]/', '', (string)($_GET['p'] ?? 'site'));
if ($pnow === '' || !isset($TYPES[$pnow])) $pnow = 'site';
$act = (string)($_GET['act'] ?? '');
$msg = (string)($_GET['msg'] ?? '');
?>
