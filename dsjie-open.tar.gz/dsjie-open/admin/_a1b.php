<?php
/** POST 路由（留言/账号类动作见 _a1c.php 的 admin_misc_post） */
require_once __DIR__ . '/_a1c.php';

$err = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $do = (string)($_POST['do'] ?? '');
    if ($do === 'login') {
        if (admin_check((string)($_POST['user'] ?? ''), (string)($_POST['pass'] ?? ''))) {
            session_regenerate_id(true);
            $_SESSION['admin'] = true;
            header('Location: index.php'); exit;
        }
        $err = '账号或密码不正确';
    } elseif (!empty($_SESSION['admin'])) {
        $data = load_data();
        $p = preg_replace('/[^a-z]/', '', (string)($_POST['p'] ?? 'site'));
        $back = 'index.php?p=' . ($p !== '' ? $p : 'site');
        $m = '';
        $replyCountBefore = null;
        $replyToId = (string)($_POST['msg_id'] ?? '');
        if ($do === 'save_reply') {
            foreach ($data['messages'] as $message) {
                if (($message['id'] ?? '') === $replyToId) {
                    $replyCountBefore = count($message['replies'] ?? []);
                    break;
                }
            }
        }
        if ($do === 'logout') { session_destroy(); header('Location: index.php'); exit; }

        if ($do === 'save_settings') {
            $sec = ($p === 'about') ? 'about' : 'site';
            $identityUpdates = [];
            foreach ($TYPES[$sec]['fields'] as $f) {
                if ($f['type'] === 'heading') continue;   // 分组标题不入库
                if ($sec === 'site' && in_array($f['key'], ['master_qq', 'master_pwd', 'mail_notify_to', 'mail_from', 'smtp_host', 'smtp_port', 'smtp_secure', 'smtp_username', 'smtp_password'], true)) {
                    $value = fld_post($f);
                    if ($f['key'] !== 'smtp_password' || $value !== '') $identityUpdates[$f['key']] = $value;
                    continue;
                }
                if ($f['type'] === 'upload') {
                    if (!empty($_FILES['up']['name'])) {
                        $np = handle_upload($_FILES['up'], $f['dir']);
                        if ($np) $data[$sec][$f['key']] = $np;
                    } else {
                        $data[$sec][$f['key']] = (string)($_POST['cur'] ?? ($data[$sec][$f['key']] ?? ''));
                    }
                } else {
                    $data[$sec][$f['key']] = fld_post($f);
                }
            }
            if ($sec === 'site') {
                for ($i = 0; $i < 7; $i++) {
                    $data['site']['socials'][$i]['label'] = clean_text($_POST['social_label'][$i] ?? '', 20);
                    $data['site']['socials'][$i]['url']   = clean_text($_POST['social_url'][$i] ?? '', 200);
                }
                if (!save_identity_config($identityUpdates)) {
                    $m = '身份或 SMTP 配置无效，或 data/identity.php 写入失败';
                }
            }
            if ($m === '') $m = '已保存';
        } elseif ($do === 'save_item') {
            $t = (string)($_POST['type'] ?? '');
            if (isset($TYPES[$t]) && $TYPES[$t]['kind'] === 'list') {
                $id = (string)($_POST['id'] ?? '');
                $item = null; $idx = -1;
                foreach ($data[$t] as $k => $it) if (($it['id'] ?? '') === $id) { $item = $it; $idx = $k; break; }
                if ($item === null) $item = ['id' => nid()];
                foreach ($TYPES[$t]['fields'] as $f) {
                    if ($f['type'] === 'heading') continue;   // 分组标题不入库
                    if ($f['type'] === 'upload') {
                        if (!empty($_FILES['up']['name'])) {
                            $np = handle_upload($_FILES['up'], $f['dir']);
                            if ($np) $item[$f['key']] = $np;
                        }
                        if (!isset($item[$f['key']])) $item[$f['key']] = (string)($_POST['cur'] ?? '');
                    } else {
                        $item[$f['key']] = fld_post($f);
                    }
                }
                if ($idx >= 0) {
                    $data[$t][$idx] = $item;
                } else {
                    $data[$t][] = $item;
                    /* 新发布作品/随笔/图库/下载 → 自动生成一条动态（编辑不重复记） */
                    $autoMap = ['works' => '作品', 'essays' => '随笔', 'gallery' => '图库', 'downloads' => '下载'];
                    if (isset($autoMap[$t])) {
                        $nm = trim((string)($item['title'] ?? ''));
                        if ($nm === '') $nm = trim((string)($item['caption'] ?? ''));
                        if ($nm === '') $nm = trim((string)($item['file'] ?? ''));
                        if ($nm === '') $nm = '未命名';
                        $verb = $t === 'gallery' ? '上传了图库图片'
                              : ($t === 'downloads' ? '新增了下载资源' : '发布了' . $autoMap[$t]);
                        $txt = trim((string)($item['desc'] ?? ''));
                        if ($txt === '') $txt = trim((string)($item['excerpt'] ?? ''));
                        if ($txt === '') $txt = trim((string)($item['note'] ?? ''));
                        $data['updates'] = array_merge([[
                            'id'    => nid(),
                            'date'  => date('Y-m-d'),
                            'title' => $verb . '《' . $nm . '》',
                            'text'  => mb_substr($txt !== '' ? $txt : '内容已发布，欢迎查看。', 0, 100, 'UTF-8'),
                        ]], $data['updates']);
                    }
                }
                $m = '已保存';
            }
        } elseif ($do === 'delete_item') {
            $t = (string)($_POST['type'] ?? ''); $id = (string)($_POST['id'] ?? '');
            if (isset($TYPES[$t]) && $TYPES[$t]['kind'] === 'list') {
                $data[$t] = array_values(array_filter($data[$t], function ($x) use ($id) { return ($x['id'] ?? '') !== $id; }));
                $m = '已删除';
            }
        } else {
            $m = admin_misc_post($do, $data, $m);
        }
        $dataSaved = save_data($data);
        if (!$dataSaved) {
            $m = '保存失败：data/content.json 不可写（权限问题）。请在站点目录执行 sh fixperm.sh，或在宝塔面板把 data/ 目录及 content.json 的属主设为 www、权限设为 755 后重试。';
        }
        if ($dataSaved && $do === 'save_reply' && $replyCountBefore !== null) {
            foreach ($data['messages'] as $message) {
                if (($message['id'] ?? '') !== $replyToId || empty($message['email'])) continue;
                $replies = $message['replies'] ?? [];
            $reply = count($replies) > $replyCountBefore ? $replies[count($replies) - 1] : null;
            if (is_array($reply)) {
                    $subject = '你的留言收到回复';
                    $body = "你的留言已收到站长回复。\n\n原留言：\n" . (string)($message['text'] ?? '') . "\n\n站长回复：\n" . (string)($reply['text'] ?? '') . "\n";
                    $html = notification_email_html($subject, '站长已经回复了你的留言。', [
                        '原留言' => (string)($message['text'] ?? ''),
                        '站长回复' => (string)($reply['text'] ?? ''),
                    ]);
                    if (!send_notification_email((string)$message['email'], $subject, $body, $html)) {
                        $mailStatus = smtp_notification_status();
                        $m = '回复已发布，但邮件通知发送失败：' . ($mailStatus !== '' ? $mailStatus : '请检查 SMTP 参数和服务器连接。');
                    }
                }
                break;
            }
        }
        header('Location: ' . $back . ($m !== '' ? '&msg=' . urlencode($m) : ''));
        exit;
    } else {
        http_response_code(403); exit('Forbidden');
    }
}
