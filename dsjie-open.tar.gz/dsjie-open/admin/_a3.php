<?php
/* ---------- 设置视图（站点 / 关于） ---------- */
function view_settings(string $sec, array $defs, array $data): void {
    $cur = $data[$sec] ?? [];
    if ($sec === 'site') {
        $identity = identity_config();
        foreach (['master_qq', 'master_pwd', 'mail_notify_to', 'mail_from', 'smtp_host', 'smtp_port', 'smtp_secure', 'smtp_username'] as $key) {
            $cur[$key] = (string)($identity[$key] ?? '');
        }
        $cur['smtp_password'] = '';
    }
    echo '<div class="panel"><div class="ptop"><h2>' . e($defs['label']) . '</h2></div>'
       . '<form method="post" class="fbox" enctype="multipart/form-data">'
       . '<input type="hidden" name="do" value="save_settings"><input type="hidden" name="p" value="' . e($sec) . '">';
    foreach ($defs['fields'] as $f) field_input($f, (string)($cur[$f['key']] ?? ''));
    if ($sec === 'site') {
        echo '<h3 class="sub">社交链接（7 个固定图标位：GitHub / 邮箱 / 博客 / RSS / QQ / 微信 / 抖音，图标样式固定，名称可改）</h3>';
        for ($i = 0; $i < 7; $i++) {
            $lb = (string)($cur['socials'][$i]['label'] ?? '');
            $ur = (string)($cur['socials'][$i]['url'] ?? '');
            echo '<div class="srow"><input name="social_label[' . $i . ']" placeholder="名称" value="' . e($lb) . '">'
               . '<input name="social_url[' . $i . ']" placeholder="链接（空=显示 #）" value="' . e($ur) . '"></div>';
        }
    }
    echo '<div class="fbtns"><button class="btn">保 存</button></div></form>';
    if ($sec === 'site') {
        $mailStatus = smtp_notification_status();
        echo '<p class="hint mail-status">' . ($mailStatus === '' ? 'SMTP 配置已就绪。' : 'SMTP 暂不可用：' . e($mailStatus)) . '</p>';
    }
    echo '</div>';
    color_js();   // 站点/关于设置页：色盘与色值框联动脚本
}

/* ---------- 留言管理 ---------- */
function view_messages(array $rows): void {
    echo '<div class="panel"><div class="ptop"><h2>留言板 <span class="num">' . count($rows) . ' 条</span></h2></div>';
    if (!$rows) echo '<p class="empty">还没有留言。</p>';
    foreach ($rows as $m) {
        echo '<div class="msgbox"><div class="mhead"><b>' . e($m['qq'] ?? '') . '</b><span class="mmail">' . e($m['email'] ?? '') . '</span><span>' . e($m['time'] ?? '') . '</span>'
           . '<form method="post" class="delf" onsubmit="return confirm(\'删除这条留言？\')">'
           . '<input type="hidden" name="do" value="delete_msg"><input type="hidden" name="p" value="messages">'
           . '<input type="hidden" name="id" value="' . e($m['id'] ?? '') . '"><button class="mini danger">删除留言</button></form></div>'
           . '<p class="mtext">' . e($m['text'] ?? '') . '</p>';
        foreach (($m['replies'] ?? []) as $r) {
            echo '<div class="mrep"><b>' . e($r['qq'] ?? '') . '</b><span>' . e($r['time'] ?? '') . '</span>　' . e($r['text'] ?? '')
               . '<form method="post" class="delf" onsubmit="return confirm(\'删除这条回复？\')">'
               . '<input type="hidden" name="do" value="delete_reply"><input type="hidden" name="p" value="messages">'
               . '<input type="hidden" name="msg_id" value="' . e($m['id'] ?? '') . '"><input type="hidden" name="rid" value="' . e($r['id'] ?? '') . '">'
               . '<button class="mini danger">删</button></form></div>';
        }
        echo '<form method="post" class="reps"><input type="hidden" name="do" value="save_reply">'
           . '<input type="hidden" name="p" value="messages"><input type="hidden" name="msg_id" value="' . e($m['id'] ?? '') . '">'
           . '<textarea name="reply" rows="2" maxlength="200" placeholder="以站长身份回复…"></textarea><button class="btn">回复</button></form></div>';
    }
    echo '</div>';
}

/* ---------- 账号 ---------- */
function view_account(array $c): void {
    echo '<div class="panel"><div class="ptop"><h2>账号安全</h2></div><form method="post" class="fbox narrow">'
       . '<input type="hidden" name="do" value="save_account"><input type="hidden" name="p" value="account">'
       . '<label class="fld"><span>用户名</span><input name="user" value="' . e($c['user']) . '" required></label>'
       . '<label class="fld"><span>新密码（留空 = 不修改）</span><input name="pass1" type="password" autocomplete="new-password"></label>'
       . '<label class="fld"><span>确认新密码</span><input name="pass2" type="password" autocomplete="new-password"></label>'
       . '<div class="fbtns"><button class="btn">保存账号</button></div></form>'
       . '<p class="hint">修改后立即生效；忘记密码可删除 data/admin.json 后用 config.php 中的默认账号登录。</p></div>';
}

require __DIR__ . '/_a4.php';
require __DIR__ . '/_a5.php';
require __DIR__ . '/_a3b.php';
