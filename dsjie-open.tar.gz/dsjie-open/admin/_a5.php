<?php
/** 过去 30 天匿名互动统计 */
require_once __DIR__ . '/../lib_analytics.php';

function view_analytics(): void {
    $events = analytics_read_events(time() - 30 * 86400);
    $labels = [
        'section_view' => '板块浏览',
        'button_click' => '按钮点击',
        'link_click' => '链接点击',
        'download' => '下载',
        'guestbook_submit' => '发表留言',
        'guestbook_reply' => '留言回复',
    ];
    $moduleLabels = [
        'site' => '网站整体', 'profile' => '头像资料区', 'navigation' => '导航区',
        'about' => '关于我', 'works' => '作品', 'essays' => '随笔', 'gallery' => '图库',
        'updates' => '动态', 'friends' => '友情链接', 'downloads' => '下载',
        'guestbook' => '留言板', 'copyright' => '版权', 'legacy' => '旧版未分类数据',
    ];
    $visitors = [];
    $groups = [];
    $pageViews = 0;
    foreach ($events as $event) {
        $visitor = (string)$event['visitor'];
        if (($event['type'] ?? '') === 'page_view') {
            $pageViews++;
            $visitors[$visitor] = true;
            continue;
        }
        $type = (string)($event['type'] ?? '');
        $label = trim((string)($event['label'] ?? ''));
        if ($label === '') $label = '未命名';
        $module = (string)($event['module'] ?? 'legacy');
        if (!isset($moduleLabels[$module])) $module = 'legacy';
        $key = $type . "\0" . $label;
        if (!isset($groups[$module][$key])) {
            $groups[$module][$key] = ['type' => $type, 'label' => $label, 'count' => 0, 'visitors' => []];
        }
        $groups[$module][$key]['count']++;
        $groups[$module][$key]['visitors'][$visitor] = true;
    }
    foreach ($groups as &$moduleGroups) {
        uasort($moduleGroups, static function ($a, $b) {
            return $b['count'] <=> $a['count'];
        });
    }
    unset($moduleGroups);

    echo '<div class="panel"><div class="ptop"><h2>点击统计 <span class="num">最近 30 天</span></h2></div>'
       . '<div class="analytics-summary"><div><span>独立访客</span><strong>' . count($visitors) . '</strong></div>'
       . '<div><span>页面访问</span><strong>' . $pageViews . '</strong></div>'
       . '<div><span>当前在线</span><strong>' . analytics_online_count() . '</strong></div></div>'
       . '<p class="hint analytics-hint">转化率 = 进行该项操作的独立访客 ÷ 独立访客。数据按匿名浏览器 ID 统计。</p>';

    if (!$groups) {
        echo '<p class="empty">暂无互动数据，访客产生操作后会显示在这里。</p></div>';
        return;
    }

    $denominator = count($visitors);
    foreach ($groups as $module => $moduleGroups) {
        echo '<section class="analytics-module"><div class="analytics-module-head"><h3>' . e($moduleLabels[$module]) . '</h3><span>' . count($moduleGroups) . ' 项</span></div>'
           . '<div class="analytics-table-wrap"><table class="tbl"><thead><tr><th>操作</th><th>名称</th><th>次数</th><th>独立访客</th><th>转化率</th></tr></thead><tbody>';
        foreach ($moduleGroups as $group) {
            $unique = count($group['visitors']);
            $rate = $denominator > 0 ? number_format($unique / $denominator * 100, 1) . '%' : '0.0%';
            echo '<tr><td data-label="操作">' . e($labels[$group['type']] ?? $group['type']) . '</td>'
               . '<td data-label="名称">' . e($group['label']) . '</td>'
               . '<td data-label="次数">' . (int)$group['count'] . '</td>'
               . '<td data-label="独立访客">' . $unique . '</td>'
               . '<td data-label="转化率">' . $rate . '</td></tr>';
        }
        echo '</tbody></table></div></section>';
    }
    echo '</div>';
}