<?php
/* ---------- 分发 + 布局（由 _a3.php 加载） ---------- */
if (!$logged) { view_login($err); exit; }
$data = load_data();
$kind = $TYPES[$pnow]['kind'];

$item = null;
if ($kind === 'list' && ($act === 'edit' || $act === 'new')) {
    if ($act === 'edit') {
        $want = (string)($_GET['id'] ?? '');
        foreach ($data[$pnow] as $it) if (($it['id'] ?? '') === $want) { $item = $it; break; }
        if ($item === null) { header('Location: index.php?p=' . $pnow . '&msg=条目不存在'); exit; }
    } else {
        $item = ['id' => ''];
    }
}

header('Content-Type: text/html; charset=utf-8');
// 手机端右上角菜单：模块面板（与前台 .mmenu-panel 同款），01-12 编号项
$mitems = '';
$mi = 0;
foreach ($TYPES as $k => $tdef) {
    $mitems .= '<a class="mitem' . ($k === $pnow ? ' on' : '') . '" href="index.php?p=' . $k . '" data-i="' . $mi . '"><span>' . sprintf('%02d', $mi + 1) . '</span>' . e($tdef['label']) . '</a>';
    $mi++;
}
echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
   . '<title>后台管理 · DSJIE</title><script>(function(){var m=null;try{m=localStorage.getItem("dsjie_theme")}catch(e){}var d=m==="dark"||(m!=="light"&&window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches);document.documentElement.setAttribute("data-theme",d?"dark":"light");})();</script><link rel="stylesheet" href="style.css">' . admin_palette() . $site_bg_js
   . '<script>(function(){try{var fv=localStorage.getItem("dsjie_font");if(fv)document.documentElement.setAttribute("data-font",fv);}catch(e){}'
   . 'try{var fwv=localStorage.getItem("dsjie_fw");if(fwv){document.documentElement.style.setProperty("--fw",fwv);var wvn=parseInt(fwv,10);document.documentElement.style.setProperty("--fws",(wvn>700?((wvn-700)*0.85/300).toFixed(2):0)+"px");}}catch(e){}'
   . 'try{var fsz=localStorage.getItem("dsjie_fs");if(fsz&&fsz!=="100")document.documentElement.style.setProperty("--fz",String(parseInt(fsz,10)/100));}catch(e){}})();</script>'
   . '</head><body class="apage">';
   // 复刻前台框架：stage/desk/window + 窗口栏 + side 个人区 + navcol 图标导航 + content/scroll 内容区
   $ICONS = [
     'site'      => "<rect x='3' y='4' width='18' height='13' rx='2'/><path d='M8 21h8M12 17v4'/>",
     'about'     => "<circle cx='12' cy='8' r='4'/><path d='M4 20c0-4 3.5-6 8-6s8 2 8 6'/>",
     'works'     => "<rect x='3' y='7' width='18' height='13' rx='2'/><path d='M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2'/>",
     'essays'    => "<path d='M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z'/><path d='M14 3v5h5'/><path d='M9 13h6M9 17h6'/>",
     'gallery'   => "<rect x='3' y='3' width='18' height='18' rx='2'/><circle cx='8.5' cy='8.5' r='1.5'/><path d='M21 15l-5-5L5 21'/>",
     'downloads' => "<path d='M12 3v12'/><path d='M7 10l5 5 5-5'/><path d='M5 21h14'/>",
     'updates'   => "<polyline points='22 12 18 12 15 21 9 3 6 12 2 12'/>",
     'friends'   => "<path d='M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71'/><path d='M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71'/>",
     'visits'    => "<circle cx='12' cy='12' r='9'/><path d='M3 12h18'/><path d='M12 3c2.6 3.4 2.6 14.6 0 18'/><path d='M12 3c-2.6 3.4-2.6 14.6 0 18'/>",
     'analytics' => "<path d='M3 21h18'/><path d='M7 21v-6'/><path d='M12 21V8'/><path d='M17 21v-9'/>",
     'messages'  => "<path d='M4 5h16v11H9l-5 4z'/><path d='M8 10h8'/>",
     'account'   => "<rect x='4' y='11' width='16' height='9' rx='2'/><path d='M8 11V8a4 4 0 0 1 8 0v3'/>",
   ];
   echo '<div class="stage"><div class="desk"><div class="window">'
   . '<div class="winbar"><div class="dots"><i></i><i></i><i></i></div>'
   . '<div class="wintitle">DSJIE 后台 · 个人主页管理</div>'
   . '<button class="theme-btn mmenu" id="mMenuBtn" aria-label="菜单"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>'
   . '<button class="theme-btn font-btn" id="fontBtnDesk" aria-label="切换字体">Aa</button>'
   . '<button class="theme-btn" id="aTheme" aria-label="切换主题">' . $themetog . '</button></div>'
   . '<div class="mmenu-panel">' . $mitems . '</div>'
   . '<div class="winbody">'
   . '<aside class="side">'
   . '<div class="avatar">' . avatar_markup($s) . '</div>'
   . '<div class="dname">' . e($s['name']) . '</div>'
   . '<p class="dslogan">个人主页 · 后台管理</p>'
   . '<div class="btnrow">'
   . '<a class="contact" href="../index.php" target="_blank">查看前台 ↗</a>'
   . '<form method="post" class="logoutf"><button name="do" value="logout" class="contact alt">退出登录</button></form>'
   . '</div>'
   . '<div class="online-count">当前模块 <strong>' . e($TYPES[$pnow]['label']) . '</strong></div>'
   . '</aside>'
   . '<nav class="navcol"><div class="navlogo">' . e($first) . '</div><div class="navitems">';
foreach ($TYPES as $k => $tdef) {
    $badge = ($k === 'messages' && count($data['messages'])) ? '<b class="cnt">' . count($data['messages']) . '</b>' : '';
    $icon  = $ICONS[$k] ?? $ICONS['site'];
    echo '<a class="navbtn' . ($k === $pnow ? ' on' : '') . '" href="index.php?p=' . $k . '">'
       . '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $icon . '</svg>'
       . '<span>' . e($tdef['label']) . '</span>' . $badge . '</a>';
}
echo '</div></nav>'
   . '<main class="content"><div class="scroll">';
if ($msg !== '') echo '<div class="flash">' . e($msg) . '</div>';

// 切换模块逻辑同前台：浏览模式把全部模块一次性渲染，点导航/滚轮/进度点只在客户端换内容，不整页刷新
$spa = ($item === null);
if ($spa) {
    $cur_i = 0; $si = 0;
    foreach ($TYPES as $k => $tdef) {
        if ($k === $pnow) $cur_i = $si;
        echo '<section class="asect' . ($k === $pnow ? ' on' : '') . '" data-i="' . $si . '">';
        if ($tdef['kind'] === 'list') view_list($k, $tdef, $data[$k]);
        elseif ($tdef['kind'] === 'settings') view_settings($k, $tdef, $data);
        elseif ($tdef['kind'] === 'visits') view_visits();
        elseif ($tdef['kind'] === 'analytics') view_analytics();
        elseif ($tdef['kind'] === 'messages') view_messages($data['messages']);
        elseif ($tdef['kind'] === 'account') view_account(admin_creds());
        echo '</section>';
        $si++;
    }
} elseif ($kind === 'list') {
    view_form($pnow, $TYPES[$pnow], $item);   // 编辑/新增保持独立整页表单
}

// 进度胶囊（与前台同款）：显示当前模块 X/N，圆点点击切换
$prog = '';
if ($spa) {
    $Np = count($TYPES); $dots = ''; $pi = 0;
    foreach ($TYPES as $k => $tdef) {
        $dots .= '<button type="button" class="pd' . ($pi === $cur_i ? ' on' : '') . '" data-i="' . $pi . '" aria-label="切换到' . e($tdef['label']) . '" title="' . e($tdef['label']) . '"></button>';
        $pi++;
    }
    $prog = '<div class="prog" id="aProg"><span class="pnum">' . ($cur_i + 1) . '/' . $Np . '</span>' . $dots . '</div>';
}
echo '<footer class="afoot">DSJIE 个人主页 · 后台 v1.0</footer>'
   . '</div></main>' . $prog
   . '</div></div></div></div>'
   . '<script>(function(){var b=document.getElementById("aTheme");if(!b)return;b.addEventListener("click",function(){'
   . 'var cur=document.documentElement.getAttribute("data-theme");var next=cur==="dark"?"light":"dark";'
   . 'document.documentElement.setAttribute("data-theme",next);'
   . 'try{localStorage.setItem("dsjie_theme",next);}catch(e){}b.classList.toggle("turn");});})();</script>'
   . '<script>(function(){'
   . 'var mbtn=document.getElementById("mMenuBtn"),mpop=document.querySelector(".mmenu-panel");'
   . 'if(mbtn&&mpop){mbtn.addEventListener("click",function(e){e.stopPropagation();var open=mpop.classList.toggle("open");mbtn.classList.toggle("on",open);});'
   . 'mpop.addEventListener("click",function(e){if(e.target&&e.target.closest&&e.target.closest(".mitem")){mpop.classList.remove("open");mbtn.classList.remove("on");}e.stopPropagation();});'
   . 'document.addEventListener("click",function(){mpop.classList.remove("open");if(mbtn)mbtn.classList.remove("on");});}'
   . 'var sects=[].slice.call(document.querySelectorAll(".asect"));if(!sects.length)return;'
   . 'var navbtns=[].slice.call(document.querySelectorAll(".navbtn"));'
   . 'var mitems=[].slice.call(document.querySelectorAll(".mitem"));'
   . 'var scroll=document.querySelector(".scroll");'
   . 'var prog=document.getElementById("aProg");'
   . 'var pnum=prog?prog.querySelector(".pnum"):null;'
   . 'var pds=prog?[].slice.call(prog.querySelectorAll(".pd")):[];'
   . 'var keys=navbtns.map(function(a){return (a.getAttribute("href")||"").split("p=")[1]||"";});'
   . 'var cur=0;sects.forEach(function(s,k){if(s.classList.contains("on"))cur=k;});'
   . 'function render(i){var N=sects.length;i=((i%N)+N)%N;cur=i;'
   . 'sects.forEach(function(s,k){s.classList.toggle("on",k===cur);});'
   . 'navbtns.forEach(function(b,k){b.classList.toggle("on",k===cur);});'
   . 'mitems.forEach(function(b,k){b.classList.toggle("on",k===cur);});'
   . 'if(scroll)scroll.scrollTop=0;'
   . 'if(pnum)pnum.textContent=(cur+1)+"/"+N;'
   . 'pds.forEach(function(d,k){d.classList.toggle("on",k===cur);});'
   . 'try{history.replaceState(null,"","index.php?p="+keys[cur]);}catch(e){}}'
   . 'navbtns.forEach(function(b,k){b.addEventListener("click",function(e){e.preventDefault();render(k);});});'
   . 'mitems.forEach(function(b,k){b.addEventListener("click",function(e){e.preventDefault();render(k);});});'
   . 'var pdrag=0;'
   . 'pds.forEach(function(d,k){d.addEventListener("click",function(){if(Date.now()-pdrag<400)return;render(k);});});'
   . 'if(prog){var dragOn=false,dragX0=0;'
   . 'var dotIdx=function(x){for(var i=0;i<pds.length;i++){var r=pds[i].getBoundingClientRect();if(x>=r.left-4&&x<=r.right+4)return i;}return -1;};'
   . 'prog.addEventListener("pointerdown",function(e){dragOn=true;dragX0=e.clientX;pdrag=0;'
   . 'if(prog.setPointerCapture){try{prog.setPointerCapture(e.pointerId);}catch(err){}}});'
   . 'prog.addEventListener("pointermove",function(e){if(!dragOn)return;'
   . 'if(Math.abs(e.clientX-dragX0)>6)pdrag=Date.now();'
   . 'var i=dotIdx(e.clientX);if(i>=0&&i!==cur)render(i);});'
   . 'var stopP=function(){dragOn=false;};'
   . 'prog.addEventListener("pointerup",stopP);prog.addEventListener("pointercancel",stopP);}'
   . 'if(scroll){var lastWheel=0;scroll.addEventListener("wheel",function(e){'
   . 'if(window.matchMedia&&window.matchMedia("(max-width:767px)").matches)return;'
   . 'var dy=e.deltaY;if(Math.abs(dy)<10)return;'
   . 'var now=Date.now();if(now-lastWheel<520)return;'
   . 'var atB=scroll.scrollTop+scroll.clientHeight>=scroll.scrollHeight-2;'
   . 'var atT=scroll.scrollTop<=2;'
   . 'if(dy>0&&atB&&cur<sects.length-1){lastWheel=now;render(cur+1);e.preventDefault();}'
   . 'else if(dy<0&&atT&&cur>0){lastWheel=now;render(cur-1);e.preventDefault();}},{passive:false});'
   . 'var tsY=0,tsEdge=0,tsOn=false;'
   . 'scroll.addEventListener("touchstart",function(e){'
   . 'if(!(window.matchMedia&&window.matchMedia("(max-width:767px)").matches)){tsOn=false;return;}'
   . 'if(e.touches.length!==1){tsOn=false;return;}'
   . 'tsY=e.touches[0].clientY;tsOn=true;'
   . 'tsEdge=(scroll.scrollTop+scroll.clientHeight>=scroll.scrollHeight-2)?1:(scroll.scrollTop<=2?2:0);},{passive:true});'
   . 'scroll.addEventListener("touchend",function(e){if(!tsOn)return;tsOn=false;'
   . 'var dy=tsY-e.changedTouches[0].clientY,now=Date.now();'
   . 'if(Math.abs(dy)<60||now-lastWheel<520)return;'
   . 'if(dy>0&&tsEdge===1&&cur<sects.length-1){lastWheel=now;render(cur+1);}'
   . 'else if(dy<0&&tsEdge===2&&cur>0){lastWheel=now;render(cur-1);}},{passive:true});'
   . 'scroll.addEventListener("touchmove",function(e){if(!tsOn||!e.touches.length)return;'
   . 'if(scroll.scrollTop<=1&&e.touches[0].clientY>tsY&&e.cancelable)e.preventDefault();},{passive:false});'
   . '}'
   . '})();</script>'
   . '<script>(function(){'
   . 'var OPTS=[["","系统默认"],["misans","MiSans"],["misans-global","MiSans Global"],["lanting","兰亭"]];'
   . 'var pop=document.createElement("div");pop.className="font-pop";'
   . 'OPTS.forEach(function(o){var b=document.createElement("button");b.textContent=o[1];b.setAttribute("data-v",o[0]);'
   . 'b.addEventListener("click",function(){try{localStorage.setItem("dsjie_font",o[0]);}catch(e){}'
   . 'if(o[0])document.documentElement.setAttribute("data-font",o[0]);else document.documentElement.removeAttribute("data-font");'
   . 'sync();});pop.appendChild(b);});'
   . 'var fx=document.createElement("div");fx.className="fextra";'
   . 'function slRow(lab,min,max,step){var d=document.createElement("div");d.className="fsl";'
   . 'var l=document.createElement("label");l.textContent=lab;'
   . 'var r=document.createElement("input");r.type="range";r.min=min;r.max=max;r.step=step;r.setAttribute("aria-label",lab);'
   . 'var b=document.createElement("b");d.appendChild(l);d.appendChild(r);d.appendChild(b);return d;}'
   . 'var row1=slRow("字号","50","200","5"),row2=slRow("粗细","200","1000","100");'
   . 'var frt=document.createElement("button");frt.className="freset";frt.type="button";frt.textContent="恢复默认";'
   . 'fx.appendChild(row1);fx.appendChild(row2);fx.appendChild(frt);pop.appendChild(fx);document.body.appendChild(pop);'
   . 'var fsr=row1.querySelector("input"),fsb=row1.querySelector("b"),fwr=row2.querySelector("input"),fwb=row2.querySelector("b");'
   . 'function fget(k,d){try{var v=localStorage.getItem(k);return v||d;}catch(e){return d;}}'
   . 'function sync(){var cur=document.documentElement.getAttribute("data-font")||"";'
   . 'Array.prototype.forEach.call(pop.querySelectorAll("button[data-v]"),function(x){x.classList.toggle("on",x.getAttribute("data-v")===cur);});}'
   . 'var fsv=fget("dsjie_fs","100"),fwv=fget("dsjie_fw","400");'
   . 'fsr.value=fsv;fsb.textContent=fsv+"%";fwr.value=fwv;fwb.textContent=fwv;sync();'
   . 'fsr.addEventListener("input",function(){var v=fsr.value;fsb.textContent=v+"%";'
   . 'try{localStorage.setItem("dsjie_fs",v);}catch(e){}'
   . 'document.documentElement.style.setProperty("--fz",String(parseInt(v,10)/100));});'
   . 'fwr.addEventListener("input",function(){var v=parseInt(fwr.value,10);fwb.textContent=String(v);'
   . 'try{localStorage.setItem("dsjie_fw",String(v));}catch(e){}'
   . 'document.documentElement.style.setProperty("--fw",String(v));'
   . 'document.documentElement.style.setProperty("--fws",(v>700?((v-700)*0.85/300).toFixed(2):0)+"px");});'
   . 'frt.addEventListener("click",function(){try{localStorage.removeItem("dsjie_fs");localStorage.removeItem("dsjie_fw");localStorage.removeItem("dsjie_font");}catch(e){}'
   . 'var ds=document.documentElement;ds.style.removeProperty("--fz");ds.style.removeProperty("--fw");ds.style.removeProperty("--fws");'
   . 'ds.removeAttribute("data-font");fsr.value="100";fsb.textContent="100%";fwr.value="400";fwb.textContent="400";sync();});'
   . 'var fbtn=document.getElementById("fontBtnDesk");'
   . 'if(fbtn)fbtn.addEventListener("click",function(ev){ev.stopPropagation();'
   . 'var show=pop.classList.toggle("show");if(show){var r=fbtn.getBoundingClientRect();pop.style.top=(r.bottom+8)+"px";'
   . 'if(r.left>innerWidth/2){pop.style.right=(innerWidth-r.right)+"px";pop.style.left="";}else{pop.style.left=r.left+"px";pop.style.right="";}}});'
   . 'document.addEventListener("click",function(){pop.classList.remove("show");});'
   . 'function initFs(){var list=[document.body],all=document.body.querySelectorAll("*"),i,n;'
   . 'for(i=0;i<all.length;i++)list.push(all[i]);'
   . 'for(i=0;i<list.length;i++){if(list[i].dataset.fs0)continue;n=parseFloat(getComputedStyle(list[i]).fontSize);if(n)list[i].dataset.fs0=n;}'
   . 'for(i=0;i<list.length;i++){if(list[i].dataset.fs0&&!list[i].style.fontSize)list[i].style.fontSize="calc("+list[i].dataset.fs0+"px * var(--fz,1))";}}'
   . 'initFs();'
   . '})();</script>'
   . '</body></html>';