/* 新手引导：首次访问分步教程
   - 未看过（localStorage dsjie_tour_v1）→ loader 淡出后自动弹出
   - 分步高亮关键区域 + 说明 + 跳过/上一步/下一步
   - 桌面端自动退出开场两栏态，保证能高亮到导航列
   - 带 ?tour=1 强制重看；Esc 跳过 */
(function () {
  var KEY = 'dsjie_tour_v1';
  var force = /[?&]tour=1(?:&|#|$)/.test(location.search);
  if (!force) { try { if (localStorage.getItem(KEY)) return; } catch (e) {} }

  /* ---- 样式注入 ---- */
  var css = document.createElement('style');
  css.textContent = [
    '.tw-mask{position:fixed;inset:0;z-index:9900;}',
    '.tw-hole{position:absolute;box-sizing:border-box;border:2px solid rgba(255,255,255,.85);border-radius:14px;box-shadow:0 0 0 100vmax rgba(0,0,0,.55);transition:left .32s cubic-bezier(.2,.8,.3,1),top .32s cubic-bezier(.2,.8,.3,1),width .32s cubic-bezier(.2,.8,.3,1),height .32s cubic-bezier(.2,.8,.3,1),background .32s;}',
    '.tw-hole.tw-full{left:0!important;top:0!important;width:100%!important;height:100%!important;border:0!important;border-radius:0!important;box-shadow:none!important;background:rgba(0,0,0,.55);}',
    '.tw-card{position:fixed;z-index:9901;box-sizing:border-box;width:min(320px,calc(100vw - 32px));background:var(--card,#fff);color:var(--t1,#111);border:1px solid var(--border,#e5e7eb);border-radius:16px;padding:16px 16px 14px;box-shadow:0 18px 48px rgba(0,0,0,.3);opacity:0;transition:left .32s cubic-bezier(.2,.8,.3,1),top .32s cubic-bezier(.2,.8,.3,1),opacity .3s;}',
    '.tw-card.tw-in{opacity:1;}',
    '.tw-card h4{margin:0 0 6px;font-size:15.5px;font-weight:800;color:var(--t1,#111);}',
    '.tw-card p{margin:0;font-size:13px;line-height:1.75;color:var(--t2,#667);}',
    '.tw-row{display:flex;align-items:center;gap:8px;margin-top:14px;}',
    '.tw-step{font-size:12px;color:var(--t2,#888);margin-right:auto;font-variant-numeric:tabular-nums;}',
    '.tw-btn{border:0;border-radius:10px;padding:8px 14px;font-size:13px;font-weight:700;cursor:pointer;transition:.15s;}',
    '.tw-skip{background:transparent;color:var(--t2,#888);}',
    '.tw-skip:hover{color:var(--t1,#333);}',
    '.tw-prev{background:var(--tint,rgba(127,127,127,.14));color:var(--t1,#333);}',
    '.tw-next{background:var(--t1,#111);color:var(--btntx,#fff);}',
    '.tw-card.tw-center{left:50%!important;top:50%!important;transform:translate(-50%,-50%);}'
  ].join('\n');
  document.head.appendChild(css);

  /* ---- 引导步骤（desk/mob 各自的高亮目标；无目标 = 居中卡片） ---- */
  var SITE_NAME = (typeof window.__SITE_NAME === 'string' && window.__SITE_NAME) ? window.__SITE_NAME : 'DSJIE';
  var STEPS = [
    { title: '欢迎第一次来', text: '嗨，欢迎来到 ' + SITE_NAME + '！花 30 秒看看这里可以怎么逛。' },
    { sel: { desk: '.side', mob: '.mhero' }, title: '关于我', text: '这里是自我介绍：头像、标语和联系方式。点「联系」按钮就能找到我。' },
    { sel: { desk: '#themeBtnDesk', mob: '#themeBtnMob' }, title: '主题与字体', text: '点这里切换深色/浅色主题；旁边的 Aa 可以换字体、调整字号和字重。' },
    { sel: { desk: '.navcol', mob: '#mmenuBtn' }, title: '切换板块', text: '点这里（手机端点右上角菜单）在 关于、作品、随笔、图库、动态、友链、下载、留言 之间切换；内容滚到底再继续滚，也能切到下一板块。', introExit: true },
    { sel: { desk: '.online-count', mob: '.online-count' }, title: '浏览统计', text: '这里显示当前在线人数和累计浏览次数；欢迎到「留言」板块留下你的脚印。' },
    { title: '开始逛吧', text: '教程到此结束，之后不会再自动出现。想重看的话，在网址后面加 ?tour=1 再打开即可。祝你逛得开心！' }
  ];

  /* ---- DOM ---- */
  var mask = document.createElement('div'); mask.className = 'tw-mask';
  var hole = document.createElement('div'); hole.className = 'tw-hole tw-full';
  var card = document.createElement('div'); card.className = 'tw-card';
  card.innerHTML = '<h4></h4><p></p><div class="tw-row"><span class="tw-step"></span>'
    + '<button class="tw-btn tw-skip" type="button">跳过</button>'
    + '<button class="tw-btn tw-prev" type="button">上一步</button>'
    + '<button class="tw-btn tw-next" type="button">下一步</button></div>';
  mask.appendChild(hole);
  document.body.appendChild(mask);
  document.body.appendChild(card);

  var cur = 0, started = false, ended = false;
  /* ---- 工具 ---- */
  function vis(sel) {
    if (!sel) return null;
    var el = document.querySelector(sel); if (!el) return null;
    var r = el.getBoundingClientRect();
    if (r.width < 6 || r.height < 6) return null;
    if (r.right < 8 || r.left > innerWidth - 8 || r.bottom < 8 || r.top > innerHeight - 8) return null;
    var st = getComputedStyle(el);
    if (st.visibility === 'hidden' || st.display === 'none' || +st.opacity === 0) return null;
    return el;
  }
  function target() {
    var s = STEPS[cur].sel; if (!s) return null;
    return vis(innerWidth < 768 ? s.mob : s.desk);
  }
  function fill() {
    var st = STEPS[cur];
    card.querySelector('h4').textContent = st.title;
    card.querySelector('p').textContent = st.text;
    card.querySelector('.tw-step').textContent = (cur + 1) + '/' + STEPS.length;
    card.querySelector('.tw-prev').style.display = cur === 0 ? 'none' : '';
    card.querySelector('.tw-next').textContent = cur === STEPS.length - 1 ? '完成' : '下一步';
  }
  function place(el) {
    if (!el) {
      hole.className = 'tw-hole tw-full'; hole.style.cssText = '';
      card.classList.add('tw-center'); return;
    }
    hole.className = 'tw-hole';
    var r = el.getBoundingClientRect(), pad = 8;
    var L = Math.max(4, r.left - pad), T = Math.max(4, r.top - pad);
    var W = Math.min(innerWidth - 4 - L, r.width + pad * 2);
    var H = Math.min(innerHeight - 4 - T, r.height + pad * 2);
    hole.style.left = L + 'px'; hole.style.top = T + 'px';
    hole.style.width = W + 'px'; hole.style.height = H + 'px';
    card.classList.remove('tw-center');
    card.style.left = ''; card.style.top = ''; card.style.transform = '';
    var cw = card.offsetWidth || 320, ch = card.offsetHeight || 170, gap = 14, m = 12;
    var left = L, top = T + H + gap;
    if (top + ch > innerHeight - m) { top = T - gap - ch; if (top < m) top = m; }
    left = Math.min(Math.max(m, left), Math.max(m, innerWidth - cw - m));
    card.style.left = left + 'px'; card.style.top = top + 'px';
  }
  function goTo(i) {
    cur = i; fill();
    var st = STEPS[i], el = target();
    /* 桌面开场态下导航列被移出视口：先退出开场态，动画结束后再高亮 */
    if (st.introExit && !el && typeof window.dsjieIntroExit === 'function') {
      window.dsjieIntroExit();
      place(null);
      setTimeout(function () { if (!ended) place(target()); }, 950);
      return;
    }
    if (el) { try { el.scrollIntoView({ block: 'center', behavior: 'auto' }); } catch (e) {} }
    place(target());
  }
  function finish() {
    if (ended) return; ended = true;
    try { localStorage.setItem(KEY, '1'); } catch (e) {}
    card.classList.remove('tw-in');
    mask.style.transition = 'opacity .3s'; mask.style.opacity = '0';
    card.style.transition = 'opacity .3s'; card.style.opacity = '0';
    setTimeout(function () {
      if (mask.parentNode) mask.parentNode.removeChild(mask);
      if (card.parentNode) card.parentNode.removeChild(card);
    }, 340);
    document.removeEventListener('keydown', onKey);
    window.removeEventListener('resize', onResize);
  }
  function onKey(e) {
    if (ended) return;
    if (e.key === 'Escape') finish();
    else if (e.key === 'ArrowRight' || e.key === 'Enter') { if (cur >= STEPS.length - 1) finish(); else goTo(cur + 1); }
    else if (e.key === 'ArrowLeft' && cur > 0) goTo(cur - 1);
  }
  var rt = null;
  function onResize() {
    if (ended) return;
    clearTimeout(rt); rt = setTimeout(function () { place(target()); }, 120);
  }
  function start() {
    if (started || ended) return; started = true;
    fill();
    hole.style.transition = 'opacity .3s,left .32s cubic-bezier(.2,.8,.3,1),top .32s cubic-bezier(.2,.8,.3,1),width .32s cubic-bezier(.2,.8,.3,1),height .32s cubic-bezier(.2,.8,.3,1),background .32s';
    hole.style.opacity = '0';
    card.classList.add('tw-in');
    goTo(0);
    requestAnimationFrame(function () { hole.style.opacity = '1'; });
    card.querySelector('.tw-next').addEventListener('click', function () {
      if (cur >= STEPS.length - 1) finish(); else goTo(cur + 1);
    });
    card.querySelector('.tw-prev').addEventListener('click', function () { if (cur > 0) goTo(cur - 1); });
    card.querySelector('.tw-skip').addEventListener('click', function () { finish(); });
    document.addEventListener('keydown', onKey);
    window.addEventListener('resize', onResize);
  }
  /* ---- 启动：等 loader 淡出（html[data-loaded]），最长兜底 8 秒 ---- */
  function boot() {
    var tries = 0;
    var iv = setInterval(function () {
      tries++;
      if (document.documentElement.hasAttribute('data-loaded') || tries > 80) {
        clearInterval(iv); setTimeout(start, 700);
      }
    }, 100);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();